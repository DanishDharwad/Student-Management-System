﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers
{
    public class StudentCoursesController : Controller
    {
        private SMS_DatabaseEntities db = new SMS_DatabaseEntities();

        // GET: StudentCourses
        public ActionResult Index()
        {
            var courses = db.Courses.Include(c => c.Faculty).Include(c => c.Program).Include(c => c.Semester);
            return View(courses.ToList());
        }

        // GET: StudentCourses/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Course course = db.Courses.Find(id);
            if (course == null)
            {
                return HttpNotFound();
            }
            return View(course);
        }

     
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers
{
    public class TimeTablesManagerController : Controller
    {
        private SMS_DatabaseEntities db = new SMS_DatabaseEntities();

        // GET: TimeTablesManager
        public ActionResult Index()
        {
            var timeTables = db.TimeTables.Include(t => t.Classroom).Include(t => t.Course);
            return View(timeTables.ToList());
        }

        // GET: TimeTablesManager/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TimeTable timeTable = db.TimeTables.Find(id);
            if (timeTable == null)
            {
                return HttpNotFound();
            }
            return View(timeTable);
        }

        // GET: TimeTablesManager/Create
        public ActionResult Create()
        {
            ViewBag.Classroom_ID = new SelectList(db.Classrooms, "Classroom_ID", "Name");
            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name");
            return View();
        }

        // POST: TimeTablesManager/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "TimeTable_ID,Name,Date,Day,Time,Course_ID,Classroom_ID")] TimeTable timeTable)
        {
            if (ModelState.IsValid)
            {
                db.TimeTables.Add(timeTable);
                db.SaveChanges();
                TempData["AlertMessage"] = "Timetable Added Successfully...!";
                return RedirectToAction("Index");
            }

            ViewBag.Classroom_ID = new SelectList(db.Classrooms, "Classroom_ID", "Name", timeTable.Classroom_ID);
            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name", timeTable.Course_ID);
            return View(timeTable);
        }

        // GET: TimeTablesManager/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TimeTable timeTable = db.TimeTables.Find(id);
            if (timeTable == null)
            {
                return HttpNotFound();
            }
            ViewBag.Classroom_ID = new SelectList(db.Classrooms, "Classroom_ID", "Name", timeTable.Classroom_ID);
            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name", timeTable.Course_ID);
            return View(timeTable);
        }

        // POST: TimeTablesManager/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "TimeTable_ID,Name,Date,Day,Time,Course_ID,Classroom_ID")] TimeTable timeTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(timeTable).State = EntityState.Modified;
                db.SaveChanges();
                TempData["AlertMessage"] = "Timetable Updated Successfully...!";
                return RedirectToAction("Index");
            }
            ViewBag.Classroom_ID = new SelectList(db.Classrooms, "Classroom_ID", "Name", timeTable.Classroom_ID);
            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name", timeTable.Course_ID);
            return View(timeTable);
        }

        // GET: TimeTablesManager/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TimeTable timeTable = db.TimeTables.Find(id);
            if (timeTable == null)
            {
                return HttpNotFound();
            }
            return View(timeTable);
        }

        // POST: TimeTablesManager/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TimeTable timeTable = db.TimeTables.Find(id);
            db.TimeTables.Remove(timeTable);
            db.SaveChanges();
            TempData["AlertMessage"] = "Timetable Deleted Successfully...!";
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

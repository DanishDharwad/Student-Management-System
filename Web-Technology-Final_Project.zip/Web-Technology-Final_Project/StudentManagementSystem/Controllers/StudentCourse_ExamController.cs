﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers
{
    public class StudentCourse_ExamController : Controller
    {
        private SMS_DatabaseEntities db = new SMS_DatabaseEntities();

        // GET: StudentCourse_Exam
        public ActionResult Index()
        {
            var course_Exam = db.Course_Exam.Include(c => c.Course);
            return View(course_Exam.ToList());
        }

        // GET: StudentCourse_Exam1/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Course_Exam course_Exam = db.Course_Exam.Find(id);
            if (course_Exam == null)
            {
                return HttpNotFound();
            }
            return View(course_Exam);
        }

        // GET: StudentCourse_Exam1/Create
        public ActionResult Create()
        {
            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name");
            return View();
        }

        // POST: StudentCourse_Exam1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Exam_ID,Course_ID,Date")] Course_Exam course_Exam)
        {
            if (ModelState.IsValid)
            {
                db.Course_Exam.Add(course_Exam);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name", course_Exam.Course_ID);
            return View(course_Exam);
        }

        // GET: StudentCourse_Exam1/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Course_Exam course_Exam = db.Course_Exam.Find(id);
            if (course_Exam == null)
            {
                return HttpNotFound();
            }
            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name", course_Exam.Course_ID);
            return View(course_Exam);
        }

        // POST: StudentCourse_Exam1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Exam_ID,Course_ID,Date")] Course_Exam course_Exam)
        {
            if (ModelState.IsValid)
            {
                db.Entry(course_Exam).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Course_ID = new SelectList(db.Courses, "Course_ID", "Course_Name", course_Exam.Course_ID);
            return View(course_Exam);
        }

        // GET: StudentCourse_Exam1/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Course_Exam course_Exam = db.Course_Exam.Find(id);
            if (course_Exam == null)
            {
                return HttpNotFound();
            }
            return View(course_Exam);
        }

        // POST: StudentCourse_Exam1/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Course_Exam course_Exam = db.Course_Exam.Find(id);
            db.Course_Exam.Remove(course_Exam);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

﻿
using StudentManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace StudentManagementSystem.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Autherize(StudentManagementSystem.Models.User userModel)
        {
            using (SMS_DatabaseEntities db = new SMS_DatabaseEntities())
            {
                var userDetails = db.Users.Where(x => x.Username == userModel.Username && x.Password == userModel.Password && x.Role == "Admin").FirstOrDefault();
                if (userDetails != null)
                {
                    Session["userID"] = userDetails.User_ID;
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var ManagerDetails = db.Users.Where(x => x.Username == userModel.Username && x.Password == userModel.Password && x.Role == "Manager").FirstOrDefault();
                    if (ManagerDetails != null)
                    {
                        Session["userID"] = ManagerDetails.User_ID;
                        return RedirectToAction("Index", "HomeManager");
                    }
                    else
                    {

                        var studentDetails = db.Users.Where(x => x.Username == userModel.Username && x.Password == userModel.Password && x.Role == "Student").FirstOrDefault();
                        if (studentDetails == null)
                        {
                            userModel.LoginErrorMessage = "Wrong username or password.";
                            return View("Index", userModel);
                        }
                        else
                        {
                            Session["userID"] = studentDetails.User_ID;

                            return RedirectToAction("Index", "HomeStudent");

                        }

                    }

                }

            }
        }
        public ActionResult LogOut()
        {
            Session.Abandon();
            return RedirectToAction("Index", "Login");
        }
    }
}
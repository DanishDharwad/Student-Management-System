﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers
{
    public class StudentAttendencesController : Controller
    {
        private SMS_DatabaseEntities db = new SMS_DatabaseEntities();

        // GET: AttendencesStudent
        public ActionResult Index()
        {
            var attendences = db.Attendences.Include(a => a.Course).Include(a => a.Student);
            return View(attendences.ToList());
        }

        // GET: AttendencesStudent/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Attendence attendence = db.Attendences.Find(id);
            if (attendence == null)
            {
                return HttpNotFound();
            }
            return View(attendence);
        }


    }
}

﻿using System.Web.Mvc;

namespace StudentManagementSystem.Controllers
{
    public class HomeStudentController : Controller
    {
        // GET: HomeStudent
        public ActionResult Index()
        {
            return View();
        }
    }
}